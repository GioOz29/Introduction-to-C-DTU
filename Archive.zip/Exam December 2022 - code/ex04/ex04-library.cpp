#include "ex04-library.h"
#include <string>
#include <vector>
#include <map>
#include <iostream>
// Task 4(a).  Write a placeholder implementation of CountingBuffer's
//             constructor and methods
CountingBuffer::CountingBuffer(int value) : def(value){
    vec.push_back(def);
    freq[def]=0;
}
// Task 4(b).  Write a working implementation of write() and frequency()
void CountingBuffer::write(int v){
    vec.push_back(v);
}
unsigned int CountingBuffer::frequency(int v){
    freq[v] = 0;
    for(auto val:vec){  // loop inside vector
        if(val == v){
            freq[v]++;
        }
    }
    return freq[v];
}
// Task 4(c).  Write a working implementation of mostFrequent()
int CountingBuffer::mostFrequent(){
    for(auto val:vec){
        freq[val] = 0;
    }
    for(auto val:vec){
        freq[val]++;
    }
    int temp = 0;
    unsigned int f = 0;
    for(auto val:vec){
        if(freq[val]>=f){
            temp = val;
            f = freq[val];
        }
    }
    return temp;
}
// Task 4(d).  Write a working implementation of clear()
void CountingBuffer::clear(){
    vec.clear();
    vec.push_back(def);
    freq.clear();
}
// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}

// g++ -std=c++20 ex04-main.cpp ex04-library.cpp ex04-library.h
// ./a.out