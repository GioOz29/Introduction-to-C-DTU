#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
void displayTeams(TournamentNode *t) {
    // Write your code here
    if(t == nullptr){
        return;
    }
    if(t->nodeType == team){
        cout << t->name << endl;
    }else if(t->nodeType == match){
        displayTeams(t->left);
        displayTeams(t->right);
    }
}

// Task 2(b).  Implement this function
unsigned int matches(TournamentNode *t) {
    // Replace the following with your code
    if(t == nullptr){
        return 0;
    }
    if(t->nodeType == match){
        return 1 + matches(t->left) + matches(t->right);
    } else {
        return matches(t->left) + matches(t->right);
    }
}

// Task 2(c).  Implement this function
string winner(TournamentNode *t) {
    // Replace the following with your code
    if(t == nullptr){
        return "";
    }
    if(t->nodeType == team){
        return t->name;
    } else if(t->nodeType == match){
        string leftwinner = winner(t->left);
        string rigthwinner = winner(t->right);

        if(t->result == leftWin){
            return leftwinner;
        } else if(t->result == rightWin){
            return rigthwinner;
        } else return "";
    } else return "";
}

// Task 2(d). Implement this function
bool wonAnyMatch(TournamentNode *t, string teamName) {
    // Replace the following with your code
    if(t == nullptr){
        return false;
    }
    if(t->nodeType == match){
        bool left = wonAnyMatch(t->left, teamName);
        bool right = wonAnyMatch(t->right, teamName);
        if((t->left->name == teamName && t->result == leftWin) || (t->right->name == teamName && t->result == rightWin)){
            return true;
        }
        if(left || right){
            return true;
        }
    }
    return false;
}